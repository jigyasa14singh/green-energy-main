import React from "react";
import { useParams } from "react-router-dom";
import { Line } from "react-chartjs-2";
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement } from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement);

const HouseDashboard = ({ houses }) => {
  const { id } = useParams();
  const house = houses.find((h) => h._id === id);

  if (!house) return <div className="p-10 text-red-500">House not found.</div>;

  const dummyChart = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [
      {
        label: "Production",
        data: [400, 420, 460, 500, 530, 490],
        borderColor: "#22c55e",
        backgroundColor: "rgba(34,197,94,0.2)",
        tension: 0.4,
        fill: true,
      },
      {
        label: "Consumption",
        data: [380, 400, 440, 470, 500, 460],
        borderColor: "#3b82f6",
        backgroundColor: "rgba(59,130,246,0.2)",
        tension: 0.4,
        fill: true,
      },
    ],
  };

  return (
    <div className="flex bg-gray-100 min-h-screen text-gray-800">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md p-6">
        <div className="flex items-center mb-6">
          <div className="w-12 h-12 rounded-full bg-green-700 text-white text-xl flex items-center justify-center font-bold">
            {house.name.charAt(0)}
          </div>
          <div className="ml-3">
            <h2 className="text-md font-semibold">{house.name}</h2>
            <p className="text-sm text-gray-500">{house.address}</p>
          </div>
        </div>

        <nav className="space-y-2 text-sm font-medium">
          <a href="#" className="flex items-center px-3 py-2 rounded bg-green-100 text-green-800">
            💰 Cost Analysis
          </a>
          <a href="#" className="flex items-center px-3 py-2 rounded hover:bg-gray-100">⚡ Energy Production</a>
          <a href="#" className="flex items-center px-3 py-2 rounded hover:bg-gray-100">🔌 Consumption</a>
          <a href="#" className="flex items-center px-3 py-2 rounded hover:bg-gray-100">🔍 Appliances</a>
          <a href="#" className="flex items-center px-3 py-2 rounded hover:bg-gray-100">🌱 Emissions</a>
          <a href="#" className="flex items-center px-3 py-2 rounded hover:bg-gray-100">💡 Tips</a>
        </nav>
      </aside>

      {/* Main */}
      <main className="flex-1 p-8 space-y-6">
        <h1 className="text-2xl font-bold mb-2">Energy Cost Analysis</h1>

        {/* Top Cost Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded shadow border-t-4 border-green-500">
            <p className="text-sm text-gray-500">Current Month Cost</p>
            <p className="text-3xl font-bold text-green-600">$142.85</p>
            <p className="text-sm text-green-600 mt-1">↓ $12.40 vs last month</p>
          </div>
          <div className="bg-white p-4 rounded shadow border-t-4 border-blue-500">
            <p className="text-sm text-gray-500">Energy Cost per kWh</p>
            <p className="text-3xl font-bold text-blue-600">$0.178</p>
            <p className="text-sm text-gray-500 mt-1">No change since last month</p>
          </div>
          <div className="bg-white p-4 rounded shadow border-t-4 border-yellow-500">
            <p className="text-sm text-gray-500">Grid Dependency Cost</p>
            <p className="text-3xl font-bold text-yellow-600">$48.32</p>
            <p className="text-sm text-green-600 mt-1">↓ $8.15 vs last month</p>
          </div>
        </div>

        {/* Middle Graph */}
        <div className="bg-white p-6 rounded shadow max-w-5xl mx-auto">
          <h2 className="text-lg font-semibold mb-4">Monthly Cost Breakdown</h2>
          <Line data={dummyChart} />
        </div>

        {/* Cost Breakdown + Savings */}
        <div className="grid md:grid-cols-3 gap-6">
          {/* Category Distribution */}
          <div className="bg-white rounded shadow p-6 col-span-1">
            <h3 className="text-lg font-semibold mb-4">Cost by Category</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex justify-between items-center">
                <div><span className="inline-block w-6 h-6 rounded bg-orange-400 mr-2"></span>HVAC</div>
                <strong>$52.78 (37%)</strong>
              </li>
              <li className="flex justify-between items-center">
                <div><span className="inline-block w-6 h-6 rounded bg-blue-500 mr-2"></span>Kitchen</div>
                <strong>$35.71 (25%)</strong>
              </li>
              <li className="flex justify-between items-center">
                <div><span className="inline-block w-6 h-6 rounded bg-purple-500 mr-2"></span>Electronics</div>
                <strong>$24.28 (17%)</strong>
              </li>
              <li className="flex justify-between items-center">
                <div><span className="inline-block w-6 h-6 rounded bg-lime-600 mr-2"></span>Lighting</div>
                <strong>$17.14 (12%)</strong>
              </li>
              <li className="flex justify-between items-center">
                <div><span className="inline-block w-6 h-6 rounded bg-gray-700 mr-2"></span>Other</div>
                <strong>$12.94 (9%)</strong>
              </li>
            </ul>
          </div>

          {/* Forecast Table */}
          <div className="bg-white rounded shadow p-6 col-span-1 md:col-span-1">
            <h3 className="text-lg font-semibold mb-4">Cost Forecast</h3>
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="text-gray-500">
                  <th>Month</th>
                  <th>Projected</th>
                  <th>Change</th>
                  <th>Savings</th>
                </tr>
              </thead>
              <tbody>
                <tr><td>Apr 2025</td><td>$138.42</td><td><span className="text-green-600">12% ↓</span></td><td>$11.50</td></tr>
                <tr><td>May 2025</td><td>$152.65</td><td><span className="text-green-600">8% ↓</span></td><td>$14.30</td></tr>
                <tr><td>Jun 2025</td><td>$175.20</td><td>Same</td><td>$22.40</td></tr>
                <tr><td>Jul 2025</td><td>$198.35</td><td><span className="text-red-500">5% ↑</span></td><td>$27.80</td></tr>
              </tbody>
            </table>
          </div>

          {/* Estimated Savings */}
          <div className="bg-green-600 text-white rounded shadow p-6 col-span-1">
            <h3 className="text-lg font-semibold mb-3">Estimated Annual Savings</h3>
            <p className="text-3xl font-bold mb-1">$287.45</p>
            <p className="text-sm mb-4">Compared to last year’s energy use</p>
            <div className="bg-green-700 rounded p-4 space-y-2 text-sm">
              <p>• Shift HVAC usage to off-peak → save $8.50/mo</p>
              <p>• Use LED bulbs → save $3.25/mo</p>
              <p>• Reduce appliance standby → $5.20/mo</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default HouseDashboard;
