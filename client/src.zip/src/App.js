import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import HouseDashboard from "./pages/HouseDashboard";

const App = () => {
  const [houses, setHouses] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/houses")
      .then((res) => res.json())
      .then((data) => setHouses(data))
      .catch((err) => console.error("Error fetching houses:", err));
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage houses={houses} />} />
        <Route path="/dashboard/:id" element={<HouseDashboard houses={houses} />} />
      </Routes>
    </Router>
  );
};

export default App;
