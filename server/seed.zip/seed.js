const mongoose = require("mongoose");
require("dotenv").config();

const House = require("./models/House");

const houses = [
  {
    name: "Redwood House",
    address: "53 Elm Street",
    stats: { production: 1200, consumption: 980, greenRatio: 65, emissions: 210 },
  },
  {
    name: "Maple Villa",
    address: "102 Maple Ave",
    stats: { production: 950, consumption: 1100, greenRatio: 58, emissions: 275 },
  },
  {
    name: "Sunset Cottage",
    address: "44 Sunset Blvd",
    stats: { production: 1500, consumption: 1400, greenRatio: 72, emissions: 180 },
  },
  {
    name: "Green Nest",
    address: "7 Garden Lane",
    stats: { production: 900, consumption: 820, greenRatio: 80, emissions: 120 },
  },
  {
    name: "Solar Heights",
    address: "89 Solar Drive",
    stats: { production: 1700, consumption: 1650, greenRatio: 77, emissions: 195 },
  },
  {
    name: "Eco Grove",
    address: "35 Treehill Rd",
    stats: { production: 1400, consumption: 1280, greenRatio: 68, emissions: 230 },
  },
  {
    name: "Skyline View",
    address: "19 Skyline St",
    stats: { production: 1350, consumption: 1230, greenRatio: 66, emissions: 205 },
  },
  {
    name: "Orchid House",
    address: "88 Orchid Ave",
    stats: { production: 1050, consumption: 990, greenRatio: 70, emissions: 160 },
  },
  {
    name: "Pinewood Estate",
    address: "20 Pine Street",
    stats: { production: 1150, consumption: 1030, greenRatio: 74, emissions: 145 },
  },
  {
    name: "Zen Bungalow",
    address: "12 Harmony Rd",
    stats: { production: 1250, consumption: 1150, greenRatio: 78, emissions: 150 },
  },
];

mongoose.connect(process.env.MONGO_URI)
  .then(async () => {
    console.log("MongoDB connected. Seeding...");
    await House.deleteMany({});
    await House.insertMany(houses);
    console.log("✅ Seeding complete.");
    process.exit();
  })
  .catch(err => {
    console.error("MongoDB connection error:", err);
    process.exit(1);
  });
