const mongoose = require('mongoose');

const HouseSchema = new mongoose.Schema({
  name: String,
  address: String,
  stats: {
    production: Number,     // in kWh
    consumption: Number,    // in kWh
    greenRatio: Number,     // in %
    emissions: Number       // in kg CO2
  }
});

module.exports = mongoose.model('House', HouseSchema);
